import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Routes, Route, Link, NavLink, useLocation, useNavigate, useParams,
} from 'react-router-dom';
import {
  AArrowDown, ArrowDownWideNarrow, ArrowLeft, ArrowRight, Bookmark, CalendarDays,
  Check, ChevronDown, ChevronLeft, ChevronRight, CircleHelp, Clapperboard,
  Clock3, Compass, Film, Filter, Flame, Heart, History, Home, Info, ListVideo,
  LogIn, LogOut, Menu, MessageCircle, Play, Plus, Search, Settings, ShieldAlert,
  SlidersHorizontal, Sparkles, Star, Trash2, Tv, UserCircle, Users, X, Zap,
} from 'lucide-react';
import { getAnimeById, normalizeAnime, searchAnime } from './api/anilist';
import {
  formatTime, readStore, safeYouTubeEmbed, STORAGE_KEYS, validHttpUrl, writeStore,
} from './lib/storage';

const GENRES = ['Action', 'Adventure', 'Comedy', 'Drama', 'Fantasy', 'Horror', 'Mahou Shoujo', 'Mecha', 'Music', 'Mystery', 'Psychological', 'Romance', 'Sci-Fi', 'Slice of Life', 'Sports', 'Supernatural', 'Thriller'];
const EMPTY = 'Chưa có anime nào trong mục này.';

function App() {
  const [catalog, setCatalog] = useState(() => readStore(STORAGE_KEYS.catalog, []));
  const [favorites, setFavorites] = useState(() => readStore(STORAGE_KEYS.favorites, []));
  const [watchlist, setWatchlist] = useState(() => readStore(STORAGE_KEYS.watchlist, []));
  const [history, setHistory] = useState(() => readStore(STORAGE_KEYS.history, {}));
  const [profile, setProfile] = useState(() => readStore(STORAGE_KEYS.profile, null));
  const [comments, setComments] = useState(() => readStore(STORAGE_KEYS.comments, {}));
  const [ratings, setRatings] = useState(() => readStore(STORAGE_KEYS.ratings, {}));
  const [settings, setSettings] = useState(() => readStore(STORAGE_KEYS.settings, { autoNext: true }));
  const [notice, setNotice] = useState('');

  useEffect(() => writeStore(STORAGE_KEYS.catalog, catalog), [catalog]);
  useEffect(() => writeStore(STORAGE_KEYS.favorites, favorites), [favorites]);
  useEffect(() => writeStore(STORAGE_KEYS.watchlist, watchlist), [watchlist]);
  useEffect(() => writeStore(STORAGE_KEYS.history, history), [history]);
  useEffect(() => writeStore(STORAGE_KEYS.profile, profile), [profile]);
  useEffect(() => writeStore(STORAGE_KEYS.comments, comments), [comments]);
  useEffect(() => writeStore(STORAGE_KEYS.ratings, ratings), [ratings]);
  useEffect(() => writeStore(STORAGE_KEYS.settings, settings), [settings]);

  const toast = useCallback((message) => {
    setNotice(message);
    window.clearTimeout(toast.timer);
    toast.timer = window.setTimeout(() => setNotice(''), 2800);
  }, []);

  const addAnime = useCallback((anime) => {
    const clean = { ...anime, id: String(anime.id || anime.anilistId || `custom-${Date.now()}`) };
    setCatalog((current) => {
      const exists = current.some((item) => String(item.id) === clean.id);
      return exists ? current.map((item) => String(item.id) === clean.id ? { ...item, ...clean } : item) : [clean, ...current];
    });
    toast('Đã thêm anime vào thư viện AnimeVerse.');
  }, [toast]);

  const updateAnime = useCallback((id, changes) => {
    setCatalog((current) => current.map((item) => String(item.id) === String(id) ? { ...item, ...changes } : item));
  }, []);

  const removeAnime = useCallback((id) => {
    setCatalog((current) => current.filter((item) => String(item.id) !== String(id)));
    setFavorites((current) => current.filter((value) => String(value) !== String(id)));
    setWatchlist((current) => current.filter((value) => String(value) !== String(id)));
    toast('Đã xóa anime khỏi thư viện trên thiết bị này.');
  }, [toast]);

  const toggleInSet = useCallback((setter, id) => {
    const key = String(id);
    setter((current) => current.includes(key) ? current.filter((value) => value !== key) : [key, ...current]);
  }, []);

  const saveProgress = useCallback((anime, episode, currentTime, duration) => {
    if (!anime || !episode) return;
    setHistory((current) => ({
      ...current,
      [String(anime.id)]: {
        animeId: String(anime.id), episodeId: String(episode.id),
        episodeNumber: episode.number, episodeTitle: episode.title || `Tập ${episode.number}`,
        animeTitle: anime.title, poster: anime.poster || '',
        currentTime: Number.isFinite(currentTime) ? currentTime : 0,
        duration: Number.isFinite(duration) ? duration : 0,
        updatedAt: new Date().toISOString(),
      },
    }));
  }, []);

  const submitComment = useCallback((animeId, body) => {
    if (!profile) return toast('Bạn cần tạo hồ sơ trên thiết bị trước.');
    const comment = { id: `${Date.now()}`, body, author: profile.displayName, createdAt: new Date().toISOString(), reported: false };
    setComments((current) => ({ ...current, [animeId]: [comment, ...(current[animeId] || [])] }));
    toast('Đã đăng bình luận trên thiết bị này.');
  }, [profile, toast]);

  const reportComment = useCallback((animeId, commentId) => {
    setComments((current) => ({ ...current, [animeId]: (current[animeId] || []).map((item) => item.id === commentId ? { ...item, reported: true } : item) }));
    toast('Đã đánh dấu bình luận để xem xét trên thiết bị này.');
  }, [toast]);

  const removeComment = useCallback((animeId, commentId) => {
    setComments((current) => ({ ...current, [animeId]: (current[animeId] || []).filter((item) => item.id !== commentId) }));
    toast('Đã xóa bình luận trên thiết bị này.');
  }, [toast]);

  const value = {
    catalog, favorites, watchlist, history, profile, comments, ratings, settings,
    setProfile, setRatings, setSettings, addAnime, updateAnime, removeAnime,
    toggleFavorite: (id) => toggleInSet(setFavorites, id),
    toggleWatchlist: (id) => toggleInSet(setWatchlist, id),
    saveProgress, submitComment, reportComment, removeComment, toast,
  };

  return (
    <AppContext.Provider value={value}>
      <div className="app-shell">
        <Header />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/discover" element={<ExplorePage />} />
            <Route path="/library" element={<LibraryPage />} />
            <Route path="/anime/:id" element={<DetailPage />} />
            <Route path="/watch/:animeId/:episodeId" element={<WatchPage />} />
            <Route path="/schedule" element={<SchedulePage />} />
            <Route path="/my-list" element={<MyListPage />} />
            <Route path="/top" element={<RankingPage />} />
            <Route path="/genres" element={<GenresPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/admin" element={<AdminPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
        <Footer />
        <MobileNav />
        {notice && <div className="toast" role="status"><Check size={16} />{notice}</div>}
      </div>
    </AppContext.Provider>
  );
}

import { createContext, useContext } from 'react';
const AppContext = createContext(null);
function useApp() { return useContext(AppContext); }

function Logo() {
  return <Link to="/" className="brand" aria-label="AnimeVerse trang chủ">
    <span className="brand-mark"><span>A</span><i>✦</i></span>
    <span className="brand-word">ANIME<span>VERSE</span><small>ENTER THE WORLD OF ANIME</small></span>
  </Link>;
}

function Header() {
  const [open, setOpen] = useState(false);
  const { profile } = useApp();
  const location = useLocation();
  useEffect(() => setOpen(false), [location.pathname]);
  const links = [
    ['/', 'Trang chủ', Home], ['/discover', 'Khám phá', Compass], ['/library', 'Thư viện', Clapperboard],
    ['/genres', 'Thể loại', Sparkles], ['/schedule', 'Lịch chiếu', CalendarDays], ['/top', 'Xếp hạng', Flame],
  ];
  return <>
    <header className="site-header">
      <div className="header-inner">
        <Logo />
        <nav className="desktop-nav" aria-label="Điều hướng chính">
          {links.map(([to, label]) => <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>{label}</NavLink>)}
        </nav>
        <div className="header-actions">
          <Link className="icon-button" to="/discover" aria-label="Tìm kiếm"><Search size={19} /></Link>
          <Link className="profile-chip" to="/profile" title="Hồ sơ">
            <span className="avatar-mini">{profile?.displayName?.slice(0, 1)?.toUpperCase() || <UserCircle size={18} />}</span>
            <span className="profile-label">{profile?.displayName || 'Tài khoản'}</span>
          </Link>
          <button className="icon-button menu-button" onClick={() => setOpen(!open)} aria-label="Mở menu"><Menu size={21} /></button>
        </div>
      </div>
      {open && <div className="mobile-menu">{links.map(([to, label, Icon]) => <NavLink key={to} to={to}><Icon size={17} />{label}</NavLink>)}<NavLink to="/my-list"><Bookmark size={17} />Danh sách của tôi</NavLink><NavLink to="/admin"><Settings size={17} />Quản lý thư viện</NavLink></div>}
    </header>
  </>;
}

function MobileNav() {
  const items = [['/', 'Nhà', Home], ['/discover', 'Khám phá', Search], ['/my-list', 'Của tôi', Bookmark], ['/profile', 'Hồ sơ', UserCircle]];
  return <nav className="mobile-bottom-nav" aria-label="Điều hướng điện thoại">
    {items.map(([to, label, Icon]) => <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => isActive ? 'bottom-link selected' : 'bottom-link'}><Icon size={19} /><span>{label}</span></NavLink>)}
  </nav>;
}

function Footer() {
  return <footer className="site-footer"><div className="footer-inner"><Logo /><p>Khám phá thế giới anime – Sống trong từng thế giới.</p><span>© {new Date().getFullYear()} AnimeVerse. Metadata anime được truy vấn từ AniList.</span></div></footer>;
}

function Poster({ anime, className = '' }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [anime?.poster]);
  return <div className={`poster-frame ${className}`}>
    {anime?.poster && !failed ? <img src={anime.poster} alt={anime.title || 'Poster anime'} loading="lazy" onError={() => setFailed(true)} /> : <div className="poster-fallback"><Sparkles size={28} /><span>ANIMEVERSE</span></div>}
    {anime?.averageScore && <span className="poster-score"><Star size={12} fill="currentColor" /> {(anime.averageScore / 10).toFixed(1)}</span>}
  </div>;
}

function AnimeCard({ anime, compact = false }) {
  if (!anime) return null;
  return <Link to={`/anime/${anime.id}`} className={`anime-card ${compact ? 'compact-card' : ''}`}>
    <Poster anime={anime} />
    <div className="anime-card-meta"><h3 title={anime.title}>{anime.title}</h3><p>{anime.year || anime.seasonYear || 'Chưa rõ năm'} <span>·</span> {anime.format || 'Anime'}</p></div>
  </Link>;
}

function EmptyState({ icon: Icon = Clapperboard, title = 'Chưa có dữ liệu', text = EMPTY, action, actionLabel }) {
  return <div className="empty-state"><span className="empty-icon"><Icon size={24} /></span><h3>{title}</h3><p>{text}</p>{action && <Link className="button button-primary button-small" to={action}>{actionLabel || 'Khám phá anime'} <ArrowRight size={15} /></Link>}</div>;
}

function Section({ title, subtitle, items, icon: Icon = Sparkles, moreTo = '/library' }) {
  if (!items?.length) return null;
  return <section className="content-section">
    <div className="section-heading"><div><div className="eyebrow"><Icon size={14} /> ANIMEVERSE COLLECTION</div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div><Link className="text-link" to={moreTo}>Xem tất cả <ArrowRight size={15} /></Link></div>
    <div className="anime-grid">{items.slice(0, 8).map((item) => <AnimeCard key={item.id} anime={item} />)}</div>
  </section>;
}

function HomePage() {
  const { catalog, history } = useApp();
  const featured = catalog.find((item) => item.featured) || catalog[0];
  const latest = [...catalog].sort((a, b) => new Date(b.addedAt || 0) - new Date(a.addedAt || 0));
  const popular = [...catalog].sort((a, b) => (b.popularity || 0) - (a.popularity || 0));
  const topRated = [...catalog].sort((a, b) => (b.averageScore || 0) - (a.averageScore || 0));
  const fantasy = catalog.filter((item) => item.genres?.includes('Fantasy'));
  const action = catalog.filter((item) => item.genres?.includes('Action'));
  const isekai = catalog.filter((item) => item.genres?.includes('Isekai'));
  return <>
    <section className={`hero ${featured?.banner ? 'has-banner' : ''}`} style={featured?.banner ? { backgroundImage: `linear-gradient(90deg, rgba(7,9,19,.96) 0%, rgba(7,9,19,.78) 48%, rgba(7,9,19,.25) 100%), url("${featured.banner}")` } : undefined}>
      <div className="hero-orb orb-one" /><div className="hero-orb orb-two" />
      <div className="hero-content">
        <div className="hero-kicker"><span className="live-dot" /> YOUR ANIME UNIVERSE</div>
        {featured ? <>
          <span className="hero-overline">ANIME NỔI BẬT TRONG THƯ VIỆN</span>
          <h1>{featured.title}</h1>
          <div className="hero-meta"><span><Star size={14} fill="currentColor" /> {featured.averageScore ? (featured.averageScore / 10).toFixed(1) : 'Chưa chấm điểm'}</span><span>{featured.year || '—'}</span><span>{featured.format || 'TV'}</span><span>{featured.episodesTotal ? `${featured.episodesTotal} tập` : 'Chưa rõ số tập'}</span></div>
          <p className="hero-description">{featured.description || 'Mở trang chi tiết để khám phá thông tin anime này.'}</p>
          <div className="hero-actions"><Link to={`/anime/${featured.id}`} className="button button-primary"><Play size={17} fill="currentColor" /> Xem chi tiết</Link><Link to="/library" className="button button-glass">Thư viện của tôi <ArrowRight size={16} /></Link></div>
        </> : <>
          <span className="hero-overline">KHÔNG GIAN ANIME CỦA RIÊNG BẠN</span>
          <h1>ENTER THE<br /><span>WORLD OF ANIME.</span></h1>
          <p className="hero-description">Một thế giới anime trong tầm tay bạn. Tìm kiếm từ hàng ngàn bộ anime, tự xây dựng thư viện và thêm nguồn phát hợp pháp của riêng mình.</p>
          <div className="hero-actions"><Link to="/discover" className="button button-primary"><Search size={17} /> Khám phá anime</Link><Link to="/admin" className="button button-glass"><Plus size={16} /> Thêm anime của bạn</Link></div>
        </>}
        <div className="hero-footnote"><ShieldAlert size={13} /> Bạn tự quản lý danh sách anime và nguồn video được cấp phép.</div>
      </div>
      {featured && <div className="hero-poster-wrap"><Poster anime={featured} className="hero-poster" /></div>}
      <div className="hero-glow" />
    </section>
    <div className="page-container">
      <div className="quick-stats">
        <div><span className="stat-icon"><Clapperboard size={18} /></span><strong>{catalog.length}</strong><small>Anime trong thư viện</small></div>
        <div><span className="stat-icon"><Film size={18} /></span><strong>{catalog.reduce((sum, item) => sum + (item.episodes?.length || 0), 0)}</strong><small>Tập đã cấu hình</small></div>
        <div><span className="stat-icon"><Play size={18} /></span><strong>{Object.keys(history).length}</strong><small>Anime trong lịch sử</small></div>
      </div>
      {catalog.length ? <>
        <Section title="Mới thêm vào thư viện" subtitle="Những anime bạn vừa thêm." items={latest} icon={Sparkles} />
        <Section title="Anime nổi bật" subtitle="Các lựa chọn được bạn đánh dấu nổi bật." items={catalog.filter((item) => item.featured)} icon={Flame} />
        <Section title="Được đánh giá cao" items={topRated} icon={Star} />
        <Section title="Hành động" items={action} icon={Zap} />
        <Section title="Fantasy" items={fantasy} icon={Sparkles} />
        <Section title="Isekai" items={isekai} icon={Compass} />
        <Section title="Được quan tâm" items={popular} icon={Flame} />
      </> : <div className="empty-library-callout"><div className="empty-art"><div className="portal-ring"><span>✦</span></div></div><div><div className="eyebrow">BẮT ĐẦU HÀNH TRÌNH</div><h2>Thư viện của bạn đang chờ những thế giới mới.</h2><p>AnimeVerse không tự thêm phim mẫu. Hãy tìm anime trên AniList rồi chọn “Thêm vào thư viện”, hoặc tạo anime riêng trong trang quản lý.</p><div className="inline-actions"><Link to="/discover" className="button button-primary"><Search size={16} /> Tìm anime trên AniList</Link><Link to="/admin" className="button button-outline"><Plus size={16} /> Quản lý thư viện</Link></div></div></div>}
      <section className="feature-band"><div><div className="eyebrow">YOUR PERSONAL COLLECTION</div><h2>Mỗi hành trình bắt đầu từ một tập phim.</h2><p>Lưu tiến độ xem, tạo danh sách riêng và quay lại đúng nơi bạn đã dừng.</p></div><Link className="button button-glass" to="/my-list">Mở danh sách của tôi <ArrowRight size={16} /></Link></section>
    </div>
  </>;
}

function ExplorePage() {
  const { catalog, addAnime } = useApp();
  const [search, setSearch] = useState('');
  const [genre, setGenre] = useState('');
  const [year, setYear] = useState('');
  const [season, setSeason] = useState('');
  const [status, setStatus] = useState('');
  const [format, setFormat] = useState('');
  const [sort, setSort] = useState('POPULARITY_DESC');
  const [results, setResults] = useState([]);
  const [page, setPage] = useState(1);
  const [hasNext, setHasNext] = useState(false);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState('');
  const [filtersOpen, setFiltersOpen] = useState(false);

  const runSearch = async (nextPage = 1, append = false) => {
    setLoading(true); setError('');
    try {
      const data = await searchAnime({ search, page: nextPage, genre, year, season, status, format, sort });
      setResults((current) => append ? [...current, ...data.media] : data.media);
      setPage(nextPage); setHasNext(Boolean(data.pageInfo?.hasNextPage)); setSearched(true);
    } catch (err) {
      setError(err.message || 'Không thể kết nối AniList.');
      if (!append) setResults([]);
    } finally { setLoading(false); }
  };
  const handleSubmit = (event) => { event.preventDefault(); runSearch(1, false); };
  const hasAnime = (id) => catalog.some((item) => Number(item.anilistId || item.id) === Number(id));
  return <div className="page-container page-top">
    <PageHeading eyebrow="ANIME DISCOVERY" title="Khám phá anime" text="Tìm kiếm dữ liệu anime công khai từ AniList, sau đó chọn bộ bạn muốn đưa vào thư viện riêng." />
    <form className="search-panel" onSubmit={handleSubmit}>
      <div className="search-input-wrap"><Search size={19} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Nhập tên anime tiếng Nhật, tiếng Anh..." aria-label="Tên anime" /><button type="submit" className="button button-primary" disabled={loading}>{loading ? <span className="spinner" /> : 'Tìm kiếm'}</button></div>
      <button type="button" className="filter-toggle" onClick={() => setFiltersOpen(!filtersOpen)}><SlidersHorizontal size={16} /> Bộ lọc nâng cao <ChevronDown size={15} className={filtersOpen ? 'rotate' : ''} /></button>
      {filtersOpen && <div className="filter-grid">
        <label>Thể loại<select value={genre} onChange={(e) => setGenre(e.target.value)}><option value="">Tất cả thể loại</option>{GENRES.map((g) => <option key={g}>{g}</option>)}</select></label>
        <label>Năm phát hành<input value={year} onChange={(e) => setYear(e.target.value.replace(/\D/g, '').slice(0, 4))} placeholder="Ví dụ: 2026" inputMode="numeric" /></label>
        <label>Mùa<select value={season} onChange={(e) => setSeason(e.target.value)}><option value="">Tất cả mùa</option><option value="WINTER">Winter</option><option value="SPRING">Spring</option><option value="SUMMER">Summer</option><option value="FALL">Fall</option></select></label>
        <label>Trạng thái<select value={status} onChange={(e) => setStatus(e.target.value)}><option value="">Tất cả trạng thái</option><option value="RELEASING">Đang phát sóng</option><option value="FINISHED">Hoàn thành</option><option value="NOT_YET_RELEASED">Sắp phát sóng</option></select></label>
        <label>Định dạng<select value={format} onChange={(e) => setFormat(e.target.value)}><option value="">Mọi định dạng</option><option value="TV">TV</option><option value="MOVIE">Movie</option><option value="OVA">OVA</option><option value="ONA">ONA</option><option value="SPECIAL">Special</option></select></label>
        <label>Sắp xếp<select value={sort} onChange={(e) => setSort(e.target.value)}><option value="POPULARITY_DESC">Phổ biến</option><option value="SCORE_DESC">Điểm cao</option><option value="START_DATE_DESC">Mới nhất</option><option value="TRENDING_DESC">Xu hướng</option><option value="TITLE_ROMAJI">Tên A–Z</option></select></label>
        <div className="filter-actions"><button className="button button-primary" type="submit" disabled={loading}>Áp dụng bộ lọc</button><button type="button" className="button button-ghost" onClick={() => { setGenre(''); setYear(''); setSeason(''); setStatus(''); setFormat(''); setSort('POPULARITY_DESC'); }}>Đặt lại</button></div>
      </div>}
    </form>
    {error && <div className="error-box"><ShieldAlert size={18} /><div><strong>Không tải được dữ liệu AniList</strong><p>{error}</p><button className="text-link" onClick={() => runSearch(1)}>Thử lại</button></div></div>}
    {loading && !results.length && <div className="loading-grid">{Array.from({ length: 12 }).map((_, i) => <div className="skeleton-card" key={i}><div className="skeleton-poster" /><div className="skeleton-line" /><div className="skeleton-line short" /></div>)}</div>}
    {results.length > 0 && <><div className="result-heading"><div><h2>Kết quả tìm kiếm</h2><p>Chọn anime để thêm vào thư viện cá nhân của bạn.</p></div><span className="result-count">{results.length} kết quả</span></div><div className="anime-grid">{results.map((raw) => { const anime = normalizeAnime(raw); const exists = hasAnime(raw.id); return <div className="search-result-card" key={raw.id}><AnimeCard anime={anime} /><button className={`add-card-button ${exists ? 'added' : ''}`} onClick={() => !exists && addAnime(anime)} disabled={exists}>{exists ? <><Check size={15} /> Đã thêm</> : <><Plus size={15} /> Thêm vào thư viện</>}</button></div>; })}</div>{hasNext && <div className="load-more-wrap"><button className="button button-outline" onClick={() => runSearch(page + 1, true)} disabled={loading}>{loading ? 'Đang tải...' : 'Tải thêm kết quả'} <ChevronDown size={16} /></button></div>}</>}
    {!loading && searched && !results.length && !error && <EmptyState icon={Search} title="Không tìm thấy anime" text="Thử một từ khóa khác hoặc bỏ bớt bộ lọc." />}
    {!searched && !loading && <div className="explore-intro"><div className="explore-icon"><Compass size={30} /></div><h2>Thế giới anime rộng lớn đang chờ bạn.</h2><p>Nhập tên anime để bắt đầu. Kết quả được lấy trực tiếp từ AniList; dữ liệu anime chưa tự động được lưu vào thư viện.</p><div className="genre-chips">{['Fantasy', 'Action', 'Adventure', 'Romance', 'Isekai', 'Sci-Fi'].map((g) => <button key={g} onClick={() => { setGenre(g); setTimeout(() => runSearch(1, false), 0); }}>{g}</button>)}</div></div>}
  </div>;
}

function PageHeading({ eyebrow, title, text, action }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{text && <p>{text}</p>}</div>{action}</div>;
}

function LibraryPage() {
  const { catalog } = useApp();
  const [query, setQuery] = useState('');
  const [genre, setGenre] = useState('');
  const [sort, setSort] = useState('new');
  const list = useMemo(() => catalog.filter((item) => `${item.title} ${item.titleRomaji} ${item.titleEnglish}`.toLowerCase().includes(query.toLowerCase()) && (!genre || item.genres?.includes(genre))).sort((a, b) => sort === 'score' ? (b.averageScore || 0) - (a.averageScore || 0) : sort === 'popular' ? (b.popularity || 0) - (a.popularity || 0) : new Date(b.addedAt || 0) - new Date(a.addedAt || 0)), [catalog, query, genre, sort]);
  return <div className="page-container page-top"><PageHeading eyebrow="YOUR COLLECTION" title="Thư viện anime" text={`${catalog.length} anime đã được thêm vào bộ sưu tập của bạn.`} action={<Link to="/admin" className="button button-primary"><Plus size={16} /> Thêm anime</Link>} />
    <div className="library-toolbar"><div className="mini-search"><Search size={17} /><input placeholder="Lọc theo tên anime..." value={query} onChange={(e) => setQuery(e.target.value)} /></div><select value={genre} onChange={(e) => setGenre(e.target.value)}><option value="">Tất cả thể loại</option>{GENRES.map((g) => <option key={g}>{g}</option>)}</select><select value={sort} onChange={(e) => setSort(e.target.value)}><option value="new">Mới thêm</option><option value="popular">Phổ biến</option><option value="score">Đánh giá cao</option></select></div>
    {list.length ? <div className="anime-grid">{list.map((item) => <AnimeCard key={item.id} anime={item} />)}</div> : <EmptyState title={catalog.length ? 'Không có kết quả phù hợp' : 'Thư viện còn trống'} text={catalog.length ? 'Hãy thay đổi từ khóa hoặc bộ lọc.' : 'Tìm anime trên AniList rồi thêm những bộ bạn muốn vào thư viện.'} action="/discover" />}
  </div>;
}

function DetailPage() {
  const { id } = useParams();
  const { catalog, favorites, watchlist, profile, toggleFavorite, toggleWatchlist, addAnime, comments, submitComment, reportComment, ratings, setRatings, toast } = useApp();
  const [remote, setRemote] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const anime = catalog.find((item) => String(item.id) === String(id)) || remote;
  useEffect(() => {
    if (catalog.some((item) => String(item.id) === String(id))) { setRemote(null); return; }
    const controller = new AbortController(); setLoading(true); setError('');
    getAnimeById(id, controller.signal).then((media) => setRemote(normalizeAnime(media))).catch((err) => { if (err.name !== 'AbortError') setError(err.message); }).finally(() => setLoading(false));
    return () => controller.abort();
  }, [id, catalog]);
  if (loading && !anime) return <div className="page-container page-top"><div className="loading-detail"><div className="skeleton-poster" /><div><div className="skeleton-line" /><div className="skeleton-line" /><div className="skeleton-line short" /></div></div></div>;
  if (!anime) return <div className="page-container page-top"><EmptyState title="Không tìm thấy anime" text={error || 'Anime này không có trong thư viện hoặc AniList không phản hồi.'} action="/discover" /></div>;
  const owned = catalog.some((item) => String(item.id) === String(anime.id));
  const fav = favorites.includes(String(anime.id));
  const watch = watchlist.includes(String(anime.id));
  const trailerId = anime.trailer?.site === 'youtube' ? anime.trailer.id : '';
  const firstPlayable = anime.episodes?.find((episode) => episode.sourceUrl);
  const userRating = ratings[anime.id] || 0;
  const related = catalog.filter((item) => String(item.id) !== String(anime.id) && (item.genres || []).some((genre) => (anime.genres || []).includes(genre))).slice(0, 6);
  const shareAnime = async () => {
    const shareData = { title: anime.title, text: `Khám phá ${anime.title} trên AnimeVerse`, url: window.location.href };
    try { if (navigator.share) await navigator.share(shareData); else if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(shareData.url); toast('Đã sao chép liên kết anime.'); } else toast('Trình duyệt không hỗ trợ chia sẻ liên kết.'); }
    catch (error) { if (error?.name !== 'AbortError') toast('Không thể chia sẻ liên kết lúc này.'); }
  };
  return <div className="detail-page">
    <div className="detail-backdrop" style={anime.banner ? { backgroundImage: `linear-gradient(180deg, rgba(8,10,20,.2), #090b14 88%), url("${anime.banner}")` } : undefined} />
    <div className="page-container detail-container">
      <Link to={owned ? '/library' : '/discover'} className="back-link"><ArrowLeft size={16} /> Quay lại</Link>
      <div className="detail-main"><Poster anime={anime} className="detail-poster" /><div className="detail-copy">
        <div className="eyebrow">ANIME DETAILS <span className="tag-muted">{anime.format || 'ANIME'}</span></div>
        <h1>{anime.title}</h1>
        <p className="detail-alt-title">{[anime.titleRomaji, anime.titleNative].filter(Boolean).join(' · ')}</p>
        <div className="detail-stats"><span><Star size={15} fill="currentColor" /> {anime.averageScore ? `${(anime.averageScore / 10).toFixed(1)} / 10` : 'Chưa có điểm'}</span><span>{anime.year || '—'}</span><span>{anime.episodesTotal || '?'} tập</span><span>{statusLabel(anime.status)}</span></div>
        <p className="detail-description">{anime.description || 'AniList chưa có mô tả cho anime này.'}</p>
        <div className="genre-chips detail-genres">{(anime.genres || []).map((g) => <Link to={`/genres?genre=${encodeURIComponent(g)}`} key={g}>{g}</Link>)}</div>
        <div className="detail-facts"><div><span>Studio</span><strong>{anime.studio || 'Chưa cập nhật'}</strong></div><div><span>Đạo diễn</span><strong>{anime.director || 'Chưa cập nhật'}</strong></div><div><span>Mùa phát hành</span><strong>{anime.season ? `${anime.season} ${anime.seasonYear || ''}` : anime.year || 'Chưa rõ'}</strong></div><div><span>Thời lượng</span><strong>{anime.duration ? `${anime.duration} phút/tập` : 'Chưa cập nhật'}</strong></div></div>
        <div className="detail-actions">{owned && firstPlayable ? <Link to={`/watch/${anime.id}/${firstPlayable.id}`} className="button button-primary"><Play size={16} fill="currentColor" /> Xem tập đầu</Link> : owned ? <span className="button button-disabled"><Play size={16} /> Chưa có nguồn phát</span> : <button className="button button-primary" onClick={() => addAnime(anime)}><Plus size={16} /> Thêm vào thư viện</button>}
          <button className={`button button-outline ${fav ? 'is-active' : ''}`} onClick={() => toggleFavorite(anime.id)}><Heart size={16} fill={fav ? 'currentColor' : 'none'} /> {fav ? 'Đã yêu thích' : 'Yêu thích'}</button>
          <button className={`button button-outline ${watch ? 'is-active' : ''}`} onClick={() => toggleWatchlist(anime.id)}><Bookmark size={16} fill={watch ? 'currentColor' : 'none'} /> {watch ? 'Đã lưu' : 'Muốn xem'}</button>
          {anime.siteUrl && <a className="button button-glass" href={anime.siteUrl} target="_blank" rel="noreferrer">AniList <ArrowRight size={14} /></a>}
          <button className="button button-glass" onClick={shareAnime}><ArrowRight size={14} /> Chia sẻ</button>
        </div>
        {trailerId && <div className="trailer-inline"><a href={`https://www.youtube.com/watch?v=${trailerId}`} target="_blank" rel="noreferrer"><Play size={14} /> Xem trailer chính thức trên YouTube <ArrowRight size={14} /></a></div>}
      </div></div>
      {anime.characters?.length > 0 && <section className="characters-section"><div className="section-heading"><div><div className="eyebrow">CHARACTER DATABASE</div><h2>Nhân vật</h2></div></div><div className="character-grid">{anime.characters.map((character) => <div className="character-card" key={character.id}>{character.image ? <img src={character.image} alt={character.name} loading="lazy" /> : <span className="character-placeholder"><Users size={19} /></span>}<strong>{character.name}</strong></div>)}</div></section>}
      <section className="episode-section"><div className="section-heading"><div><div className="eyebrow">WATCH EPISODES</div><h2>Danh sách tập</h2><p>{owned ? 'Chọn tập để xem từ nguồn video bạn đã cấu hình.' : 'Thêm anime vào thư viện để quản lý danh sách tập và nguồn phát.'}</p></div><span className="episode-count">{anime.episodes?.length || 0} tập đã thêm</span></div>
        {anime.episodes?.length ? <div className="episode-grid">{anime.episodes.map((episode) => <Link key={episode.id} to={`/watch/${anime.id}/${episode.id}`} className="episode-tile"><span className="episode-play"><Play size={16} fill="currentColor" /></span><span><strong>Tập {episode.number}</strong><small>{episode.title || `Tập ${episode.number}`}</small></span><span className="episode-source">{episode.sourceUrl ? 'Có nguồn' : 'Chưa có video'}</span></Link>)}</div> : <EmptyState icon={ListVideo} title="Chưa có tập phim" text="Bạn có thể thêm từng tập và đường dẫn video được cấp phép trong trang quản lý." action={owned ? '/admin' : undefined} actionLabel="Mở quản lý anime" />}
      </section>
      {related.length > 0 && <section className="related-section"><div className="section-heading"><div><div className="eyebrow">YOU MAY ALSO LIKE</div><h2>Anime tương tự</h2></div></div><div className="anime-grid related-grid">{related.map((item) => <AnimeCard key={item.id} anime={item} />)}</div></section>}
      {owned && <section className="review-section"><div className="section-heading"><div><div className="eyebrow">COMMUNITY</div><h2>Đánh giá & bình luận</h2></div></div><div className="rating-box"><div><h3>Đánh giá của bạn</h3><p>Chấm điểm anime từ 1 đến 10.</p></div><div className="rating-scale">{Array.from({ length: 10 }, (_, i) => i + 1).map((value) => <button key={value} disabled={!profile} title={!profile ? 'Tạo hồ sơ trước khi đánh giá' : `Chấm ${value}/10`} className={userRating >= value ? 'chosen' : ''} onClick={() => { if (!profile) return toast('Hãy tạo hồ sơ trong mục Tài khoản trước khi đánh giá.'); setRatings((current) => ({ ...current, [anime.id]: value })); }}>{value}</button>)}</div></div><Comments animeId={anime.id} comments={comments[anime.id] || []} onSubmit={submitComment} onReport={reportComment} /></section>}
    </div>
  </div>;
}

function Comments({ animeId, comments, onSubmit, onReport }) {
  const { profile } = useApp();
  const [body, setBody] = useState('');
  return <div className="comments-panel"><form onSubmit={(e) => { e.preventDefault(); if (body.trim()) { onSubmit(animeId, body.trim()); setBody(''); } }}><textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder={profile ? 'Chia sẻ cảm nhận của bạn...' : 'Đăng nhập hồ sơ trên thiết bị để bình luận.'} disabled={!profile} maxLength={500} /><div className="comment-submit"><span>{comments.length} bình luận · tối đa 500 ký tự</span><button className="button button-primary button-small" disabled={!profile || !body.trim()}>Gửi bình luận <MessageCircle size={14} /></button></div></form>{comments.length ? comments.map((item) => <div className="comment-item" key={item.id}><span className="comment-avatar">{item.author?.slice(0, 1)?.toUpperCase() || 'A'}</span><div><strong>{item.author}</strong><small>{new Date(item.createdAt).toLocaleString('vi-VN')}</small><p>{item.body}</p>{!item.reported && <button className="comment-report" onClick={() => onReport(animeId, item.id)}>Báo cáo</button>}{item.reported && <small className="reported-label">Đã báo cáo</small>}</div></div>) : <p className="muted-note">Chưa có bình luận nào.</p>}</div>;
}

function WatchPage() {
  const { animeId, episodeId } = useParams();
  const navigate = useNavigate();
  const { catalog, history, saveProgress, settings, setSettings } = useApp();
  const anime = catalog.find((item) => String(item.id) === String(animeId));
  const episode = anime?.episodes?.find((item) => String(item.id) === String(episodeId));
  const ordered = [...(anime?.episodes || [])].sort((a, b) => Number(a.number) - Number(b.number));
  const currentIndex = ordered.findIndex((item) => String(item.id) === String(episodeId));
  const previous = currentIndex > 0 ? ordered[currentIndex - 1] : null;
  const next = currentIndex >= 0 && currentIndex < ordered.length - 1 ? ordered[currentIndex + 1] : null;
  const videoRef = useRef(null);
  const [theater, setTheater] = useState(false);
  const [sourceError, setSourceError] = useState('');
  const resume = history[String(animeId)];
  const isCurrentResume = resume && String(resume.episodeId) === String(episodeId);
  const youtubeEmbed = episode?.sourceType === 'youtube' ? safeYouTubeEmbed(episode.sourceUrl) : '';
  const htmlSourceValid = episode?.sourceType === 'html5' && validHttpUrl(episode.sourceUrl) && episode.sourceUrl.startsWith('https://');

  useEffect(() => { setSourceError(''); }, [episodeId]);
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !isCurrentResume || !resume?.currentTime) return;
    const restore = () => { try { video.currentTime = Math.min(resume.currentTime, Math.max(0, (video.duration || resume.duration) - 5)); } catch { /* metadata may not be seekable */ } };
    video.addEventListener('loadedmetadata', restore, { once: true });
    return () => video.removeEventListener('loadedmetadata', restore);
  }, [episodeId, isCurrentResume, resume?.currentTime, resume?.duration]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || !anime || !episode) return undefined;
    const persist = () => saveProgress(anime, episode, video.currentTime, video.duration);
    const interval = window.setInterval(persist, 6000);
    return () => { window.clearInterval(interval); persist(); };
  }, [anime, episode, saveProgress]);

  if (!anime) return <div className="page-container page-top"><EmptyState title="Anime không tồn tại trong thư viện" text="Hãy thêm anime vào thư viện trước khi mở trình phát." action="/discover" /></div>;
  if (!episode) return <div className="page-container page-top"><EmptyState title="Không tìm thấy tập phim" text="Tập này có thể đã bị xóa khỏi danh sách." action={`/anime/${anime.id}`} actionLabel="Quay lại anime" /></div>;
  const goTo = (target) => target && navigate(`/watch/${anime.id}/${target.id}`);
  return <div className={`watch-page page-container ${theater ? 'theater-mode' : ''}`}>
    <div className="watch-topline"><Link to={`/anime/${anime.id}`} className="back-link"><ArrowLeft size={16} /> {anime.title}</Link><span className="watch-index">TẬP {episode.number}</span></div>
    <div className="player-layout"><div className="player-column">
      <div className={`video-stage ${theater ? 'theater' : ''}`}>
        {htmlSourceValid ? <video key={episode.id} ref={videoRef} src={episode.sourceUrl} controls playsInline preload="metadata" onError={() => setSourceError('Không thể tải video. Kiểm tra lại đường dẫn, quyền truy cập hoặc định dạng video.')} onEnded={() => { saveProgress(anime, episode, 0, videoRef.current?.duration || 0); if (settings.autoNext && next) goTo(next); }} />
          : youtubeEmbed ? <iframe key={episode.id} src={youtubeEmbed} title={`${anime.title} - tập ${episode.number}`} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen referrerPolicy="strict-origin-when-cross-origin" />
          : <div className="no-video"><div className="no-video-icon"><Play size={30} /></div><h2>Chưa có nguồn phát hợp lệ</h2><p>Tập này chưa được cấu hình video, hoặc đường dẫn chưa đúng định dạng HTTPS / YouTube được cho phép nhúng.</p><Link to="/admin" className="button button-outline"><Settings size={16} /> Cấu hình nguồn video</Link></div>}
        {theater && <button className="exit-theater" onClick={() => setTheater(false)}><X size={17} /> Thoát rạp</button>}
      </div>
      {sourceError && <div className="error-box compact-error"><ShieldAlert size={17} />{sourceError}</div>}
      <div className="player-controls-row"><button className="button button-outline button-small" disabled={!previous} onClick={() => goTo(previous)}><ChevronLeft size={16} /> Tập trước</button><button className="button button-outline button-small" onClick={() => setTheater(!theater)}><Film size={16} /> {theater ? 'Thoát rạp' : 'Chế độ rạp'}</button><button className="button button-outline button-small" disabled={!next} onClick={() => goTo(next)}>Tập tiếp <ChevronRight size={16} /></button></div>
      <div className="episode-info"><div className="eyebrow">NOW PLAYING</div><h1>{anime.title}</h1><h2>Tập {episode.number}: {episode.title || `Tập ${episode.number}`}</h2><p>{episode.description || 'Bạn đang xem nội dung từ nguồn video do chủ thư viện cấu hình.'}</p></div>
      <div className="autonext-setting"><label className="toggle-label"><input type="checkbox" checked={Boolean(settings.autoNext)} onChange={(e) => setSettings((current) => ({ ...current, autoNext: e.target.checked }))} /><span className="toggle-ui" /> Tự động chuyển tập tiếp theo</label><span className="muted-note">Tiến độ video HTML5 được lưu trên thiết bị.</span></div>
    </div><aside className="watch-sidebar"><div className="sidebar-title"><div><h3>Danh sách tập</h3><p>{ordered.length} tập đã cấu hình</p></div><ListVideo size={19} /></div>{ordered.length ? <div className="watch-episode-list">{ordered.map((item) => <button key={item.id} className={String(item.id) === String(episode.id) ? 'watch-episode active' : 'watch-episode'} onClick={() => goTo(item)}><span className="watch-episode-number">{String(item.number).padStart(2, '0')}</span><span><strong>{item.title || `Tập ${item.number}`}</strong><small>{item.sourceUrl ? 'Nguồn đã cấu hình' : 'Chưa có nguồn video'}</small></span>{String(item.id) === String(episode.id) ? <span className="playing-indicator"><i /><i /><i /></span> : <Play size={14} />}</button>)}</div> : <EmptyState title="Chưa có tập" />}</aside></div>
  </div>;
}

function SchedulePage() {
  const { catalog } = useApp();
  const days = ['Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy', 'Chủ Nhật'];
  const [selected, setSelected] = useState(days[(new Date().getDay() + 6) % 7]);
  const list = catalog.filter((item) => item.scheduleDay === selected).sort((a, b) => (a.scheduleTime || '').localeCompare(b.scheduleTime || ''));
  return <div className="page-container page-top"><PageHeading eyebrow="WEEKLY BROADCAST" title="Lịch chiếu anime" text="Lịch chiếu do bạn tự thiết lập trong trang quản lý anime." /><div className="day-tabs">{days.map((day) => <button key={day} className={selected === day ? 'active' : ''} onClick={() => setSelected(day)}>{day}</button>)}</div>{list.length ? <div className="schedule-list">{list.map((anime) => <div className="schedule-row" key={anime.id}><Poster anime={anime} /><div className="schedule-copy"><strong>{anime.title}</strong><p>{anime.episodes?.length ? `${anime.episodes.length} tập đã cấu hình` : 'Chưa thêm tập'} · {statusLabel(anime.status)}</p></div><div className="schedule-time"><Clock3 size={15} />{anime.scheduleTime || 'Chưa đặt giờ'}</div><Link className="icon-button" to={`/anime/${anime.id}`}><ArrowRight size={18} /></Link></div>)}</div> : <EmptyState icon={CalendarDays} title="Chưa có lịch chiếu cho ngày này" text="Vào Quản lý thư viện, chọn anime và thiết lập thứ cùng giờ phát sóng." action="/admin" actionLabel="Thiết lập lịch chiếu" />}</div>;
}

function MyListPage() {
  const { catalog, favorites, watchlist, history } = useApp();
  const [tab, setTab] = useState('history');
  const map = new Map(catalog.map((item) => [String(item.id), item]));
  const items = tab === 'favorites' ? favorites.map((id) => map.get(id)).filter(Boolean) : tab === 'watchlist' ? watchlist.map((id) => map.get(id)).filter(Boolean) : Object.values(history).sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)).map((entry) => map.get(String(entry.animeId))).filter(Boolean);
  return <div className="page-container page-top"><PageHeading eyebrow="PERSONAL SPACE" title="Danh sách của tôi" text="Mọi thứ bạn muốn xem, đang xem và đã lưu gần đây." /><div className="segmented-tabs"><button className={tab === 'history' ? 'active' : ''} onClick={() => setTab('history')}><History size={16} /> Lịch sử xem</button><button className={tab === 'favorites' ? 'active' : ''} onClick={() => setTab('favorites')}><Heart size={16} /> Yêu thích</button><button className={tab === 'watchlist' ? 'active' : ''} onClick={() => setTab('watchlist')}><Bookmark size={16} /> Muốn xem</button></div>{items.length ? <div className="anime-grid">{items.map((item) => <AnimeCard key={item.id} anime={item} />)}</div> : <EmptyState icon={tab === 'history' ? History : tab === 'favorites' ? Heart : Bookmark} title="Danh sách này còn trống" text={tab === 'history' ? 'Mở một tập có nguồn video hợp lệ để bắt đầu lưu lịch sử xem.' : 'Mở trang chi tiết anime và chọn nút lưu tương ứng.'} action="/library" actionLabel="Mở thư viện" />}</div>;
}

function RankingPage() {
  const { catalog } = useApp();
  const [sort, setSort] = useState('score');
  const list = [...catalog].sort((a, b) => sort === 'popular' ? (b.popularity || 0) - (a.popularity || 0) : (b.averageScore || 0) - (a.averageScore || 0));
  return <div className="page-container page-top"><PageHeading eyebrow="ANIME RANKINGS" title="Bảng xếp hạng" text="Xếp hạng trong phạm vi thư viện anime của bạn." /><div className="library-toolbar"><div className="muted-note">{list.length} anime trong bảng xếp hạng</div><select value={sort} onChange={(e) => setSort(e.target.value)}><option value="score">Điểm đánh giá cao</option><option value="popular">Độ phổ biến</option></select></div>{list.length ? <div className="ranking-list">{list.map((anime, index) => <div className="ranking-row" key={anime.id}><span className="rank-number">{String(index + 1).padStart(2, '0')}</span><Poster anime={anime} /><div className="ranking-copy"><Link to={`/anime/${anime.id}`}>{anime.title}</Link><p>{anime.year || '—'} · {anime.format || 'Anime'} · {anime.genres?.slice(0, 3).join(', ')}</p></div><div className="ranking-score"><Star size={15} fill="currentColor" />{anime.averageScore ? (anime.averageScore / 10).toFixed(1) : '—'}</div></div>)}</div> : <EmptyState title="Chưa có dữ liệu xếp hạng" text="Thêm anime vào thư viện để bảng xếp hạng được tạo tự động." action="/discover" />}</div>;
}

function GenresPage() {
  const { catalog } = useApp();
  const params = new URLSearchParams(window.location.hash.split('?')[1] || '');
  const [selected, setSelected] = useState(params.get('genre') || '');
  const list = selected ? catalog.filter((item) => item.genres?.includes(selected)) : catalog;
  return <div className="page-container page-top"><PageHeading eyebrow="GENRE EXPLORER" title="Khám phá theo thể loại" text="Chọn một thể loại để lọc các anime trong thư viện của bạn." /><div className="genre-browser">{GENRES.map((genre) => <button key={genre} className={selected === genre ? 'active' : ''} onClick={() => setSelected(selected === genre ? '' : genre)}>{genre}<span>{catalog.filter((item) => item.genres?.includes(genre)).length}</span></button>)}</div><div className="result-heading"><div><h2>{selected || 'Tất cả anime'}</h2><p>{list.length} anime phù hợp</p></div><button className="text-link" onClick={() => setSelected('')}>Xóa lọc</button></div>{list.length ? <div className="anime-grid">{list.map((item) => <AnimeCard key={item.id} anime={item} />)}</div> : <EmptyState title="Chưa có anime trong thể loại này" text="Thêm anime có gắn thể loại tương ứng vào thư viện." action="/discover" />}</div>;
}

function ProfilePage() {
  const { profile, setProfile, favorites, watchlist, history, catalog, settings, setSettings, toast } = useApp();
  const [name, setName] = useState(profile?.displayName || '');
  const [email, setEmail] = useState(profile?.email || '');
  const save = (e) => { e.preventDefault(); if (!name.trim()) return; setProfile({ displayName: name.trim(), email: email.trim(), avatar: '' }); toast('Đã lưu hồ sơ cục bộ.'); };
  return <div className="page-container page-top"><PageHeading eyebrow="YOUR PROFILE" title="Tài khoản cá nhân" text="Hồ sơ demo được lưu trong trình duyệt hiện tại." /><div className="profile-layout"><section className="profile-card"><div className="profile-avatar-large">{profile?.displayName?.slice(0, 1)?.toUpperCase() || <UserCircle size={36} />}</div><h2>{profile?.displayName || 'Khách AnimeVerse'}</h2><p>{profile?.email || 'Chưa thiết lập thông tin'}</p><form className="profile-form" onSubmit={save}><label>Tên hiển thị<input value={name} onChange={(e) => setName(e.target.value)} placeholder="Tên của bạn" required maxLength={32} /></label><label>Email (không bắt buộc)<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" /></label><button className="button button-primary" type="submit">Lưu hồ sơ <Check size={16} /></button></form>{profile && <button className="button button-ghost logout-button" onClick={() => { setProfile(null); setName(''); setEmail(''); }}> <LogOut size={16} /> Xóa hồ sơ khỏi thiết bị</button>}</section><section className="profile-side"><div className="profile-stats"><div><strong>{favorites.length}</strong><span>Yêu thích</span></div><div><strong>{watchlist.length}</strong><span>Muốn xem</span></div><div><strong>{Object.keys(history).length}</strong><span>Lịch sử</span></div><div><strong>{catalog.length}</strong><span>Thư viện</span></div></div><div className="settings-card"><div className="eyebrow">PLAYBACK SETTINGS</div><h3>Cài đặt trình phát</h3><label className="toggle-label"><input type="checkbox" checked={Boolean(settings.autoNext)} onChange={(e) => setSettings((current) => ({ ...current, autoNext: e.target.checked }))} /><span className="toggle-ui" /> Tự động phát tập tiếp theo</label><p>Hồ sơ, danh sách yêu thích và lịch sử xem hiện chỉ đồng bộ trong trình duyệt này. Để có đăng nhập thật và đồng bộ nhiều thiết bị, cần kết nối backend như Supabase hoặc Firebase.</p></div></section></div></div>;
}

function AdminPage() {
  const { catalog, comments, addAnime, updateAnime, removeAnime, removeComment, toast } = useApp();
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedId, setSelectedId] = useState(catalog[0]?.id || '');
  const [epNumber, setEpNumber] = useState('1');
  const [epTitle, setEpTitle] = useState('');
  const [sourceType, setSourceType] = useState('html5');
  const [sourceUrl, setSourceUrl] = useState('');
  const [epDescription, setEpDescription] = useState('');
  const [rightsConfirmed, setRightsConfirmed] = useState(false);
  const [manualTitle, setManualTitle] = useState('');
  const [manualPoster, setManualPoster] = useState('');
  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [scheduleDay, setScheduleDay] = useState('');
  const [scheduleTime, setScheduleTime] = useState('');
  const selectedAnime = catalog.find((item) => String(item.id) === String(selectedId));
  const reportedComments = Object.entries(comments).flatMap(([animeId, list]) => list.filter((item) => item.reported).map((item) => ({ ...item, animeId, animeTitle: catalog.find((anime) => String(anime.id) === String(animeId))?.title || 'Anime đã xóa' }))); 

  const findForImport = async (e) => {
    e.preventDefault(); setLoading(true);
    try { const data = await searchAnime({ search: query, page: 1, sort: 'POPULARITY_DESC' }); setSearchResults(data.media || []); }
    catch (err) { toast(`AniList lỗi: ${err.message}`); }
    finally { setLoading(false); }
  };
  const addEpisode = (e) => {
    e.preventDefault();
    if (!selectedAnime) return toast('Hãy chọn anime trước.');
    if (!rightsConfirmed) return toast('Bạn cần xác nhận có quyền sử dụng nguồn video này.');
    if (!sourceUrl.trim()) return toast('Vui lòng nhập đường dẫn nguồn video.');
    if (sourceType === 'youtube' && !safeYouTubeEmbed(sourceUrl)) return toast('Đường dẫn YouTube chưa hợp lệ.');
    if (sourceType === 'html5' && (!validHttpUrl(sourceUrl) || !sourceUrl.startsWith('https://'))) return toast('Video HTML5 cần đường dẫn HTTPS hợp lệ.');
    const number = Number(epNumber);
    if (!Number.isInteger(number) || number < 1) return toast('Số tập phải là số nguyên lớn hơn 0.');
    if (selectedAnime.episodes?.some((ep) => Number(ep.number) === number)) return toast('Tập này đã tồn tại.');
    const episode = { id: `${selectedAnime.id}-ep-${number}`, number, title: epTitle.trim() || `Tập ${number}`, description: epDescription.trim(), sourceType, sourceUrl: sourceUrl.trim(), createdAt: new Date().toISOString() };
    updateAnime(selectedAnime.id, { episodes: [...(selectedAnime.episodes || []), episode].sort((a, b) => a.number - b.number) });
    setEpTitle(''); setEpDescription(''); setSourceUrl(''); setRightsConfirmed(false); toast(`Đã thêm tập ${number} vào ${selectedAnime.title}.`);
  };
  const addManual = (e) => {
    e.preventDefault(); if (!manualTitle.trim()) return;
    const id = `custom-${Date.now()}`;
    addAnime({ id, title: manualTitle.trim(), poster: manualPoster.trim(), description: '', genres: [], episodes: [], format: 'TV', status: 'UNKNOWN', addedAt: new Date().toISOString(), featured: false, custom: true });
    setSelectedId(id); setManualTitle(''); setManualPoster('');
  };
  const saveSchedule = () => { if (!selectedAnime) return; updateAnime(selectedAnime.id, { scheduleDay, scheduleTime }); toast('Đã lưu lịch chiếu.'); };
  const toggleFeatured = () => { if (!selectedAnime) return; updateAnime(selectedAnime.id, { featured: !selectedAnime.featured }); toast(selectedAnime.featured ? 'Đã bỏ nổi bật.' : 'Đã đánh dấu anime nổi bật.'); };
  const saveAnimeDetails = () => { if (!selectedAnime || !editTitle.trim()) return; updateAnime(selectedAnime.id, { title: editTitle.trim(), description: editDescription.trim() }); toast('Đã cập nhật thông tin anime.'); };
  const removeEpisode = (episodeId) => { updateAnime(selectedAnime.id, { episodes: selectedAnime.episodes.filter((ep) => String(ep.id) !== String(episodeId)) }); toast('Đã xóa tập phim.'); };

  useEffect(() => { if (!catalog.length) setSelectedId(''); else if (!catalog.some((item) => String(item.id) === String(selectedId))) setSelectedId(catalog[0].id); }, [catalog, selectedId]);
  useEffect(() => { setScheduleDay(selectedAnime?.scheduleDay || ''); setScheduleTime(selectedAnime?.scheduleTime || ''); setEditTitle(selectedAnime?.title || ''); setEditDescription(selectedAnime?.description || ''); }, [selectedId]);

  return <div className="page-container page-top admin-page"><PageHeading eyebrow="LIBRARY MANAGEMENT" title="Quản lý AnimeVerse" text="Nhập dữ liệu anime, tự quản lý tập phim và cấu hình nguồn phát hợp pháp." />
    <div className="admin-warning"><ShieldAlert size={20} /><div><strong>Chế độ quản lý cục bộ — chưa có bảo mật admin phía máy chủ</strong><p>Trang này dành cho bản demo tĩnh: dữ liệu chỉ lưu trong trình duyệt của bạn. Không dùng để quản trị website công khai có nhiều người dùng; cần backend xác thực và phân quyền trước khi phát hành thực tế.</p></div></div>
    <div className="admin-grid"><section className="admin-card"><div className="card-title-row"><div><div className="eyebrow">IMPORT FROM ANILIST</div><h2>Thêm anime từ AniList</h2></div><Sparkles size={20} /></div><form className="admin-search-form" onSubmit={findForImport}><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Nhập tên anime..." required /><button className="button button-primary" disabled={loading}>{loading ? <span className="spinner" /> : <Search size={16} />}</button></form>{searchResults.length > 0 && <div className="admin-search-results">{searchResults.slice(0, 8).map((raw) => { const anime = normalizeAnime(raw); const exists = catalog.some((item) => String(item.id) === anime.id); return <div className="admin-search-item" key={raw.id}><Poster anime={anime} /><div><strong>{anime.title}</strong><small>{anime.year || '—'} · {anime.format} · {anime.genres.slice(0, 2).join(', ')}</small></div><button className="icon-button" disabled={exists} title={exists ? 'Đã có trong thư viện' : 'Thêm anime'} onClick={() => { addAnime(anime); setSelectedId(anime.id); }} >{exists ? <Check size={17} /> : <Plus size={18} />}</button></div>; })}</div>}<div className="admin-divider" /><div className="eyebrow">CREATE MANUALLY</div><h3>Tạo anime riêng</h3><form className="manual-form" onSubmit={addManual}><label>Tên anime<input value={manualTitle} onChange={(e) => setManualTitle(e.target.value)} placeholder="Tên anime" required /></label><label>URL poster (không bắt buộc)<input value={manualPoster} onChange={(e) => setManualPoster(e.target.value)} placeholder="https://..." /></label><button className="button button-outline" type="submit"><Plus size={15} /> Tạo anime</button></form></section>
      <section className="admin-card"><div className="card-title-row"><div><div className="eyebrow">EPISODE & SOURCE</div><h2>Thêm tập phim</h2></div><Film size={20} /></div><label className="full-label">Chọn anime<select value={selectedId} onChange={(e) => setSelectedId(e.target.value)}><option value="">-- Chọn anime --</option>{catalog.map((item) => <option key={item.id} value={item.id}>{item.title}</option>)}</select></label>{selectedAnime ? <><form className="episode-form" onSubmit={addEpisode}><div className="form-two"><label>Số tập<input inputMode="numeric" type="number" min="1" value={epNumber} onChange={(e) => setEpNumber(e.target.value)} required /></label><label>Tên tập<input value={epTitle} onChange={(e) => setEpTitle(e.target.value)} placeholder="Tập 01" /></label></div><label>Loại nguồn<select value={sourceType} onChange={(e) => setSourceType(e.target.value)}><option value="html5">HTML5 Video (MP4/WebM)</option><option value="youtube">YouTube Embed được cho phép</option></select></label><label>Đường dẫn video<input value={sourceUrl} onChange={(e) => setSourceUrl(e.target.value)} placeholder={sourceType === 'youtube' ? 'https://www.youtube.com/watch?v=...' : 'https://cdn.example.com/video.mp4'} required /></label><label>Mô tả tập<textarea value={epDescription} onChange={(e) => setEpDescription(e.target.value)} placeholder="Mô tả ngắn..." rows="2" /></label><label className="rights-check"><input type="checkbox" checked={rightsConfirmed} onChange={(e) => setRightsConfirmed(e.target.checked)} /> Tôi có quyền phân phối hoặc nhúng nguồn video này.</label><button className="button button-primary" type="submit"><Plus size={15} /> Thêm tập phim</button></form><div className="admin-divider" /><div className="card-title-row"><h3>Tập đã cấu hình ({selectedAnime.episodes?.length || 0})</h3><span className="tag-muted">{selectedAnime.title}</span></div>{selectedAnime.episodes?.length ? <div className="managed-episodes">{selectedAnime.episodes.map((ep) => <div key={ep.id}><span><strong>Tập {ep.number}</strong><small>{ep.title} · {ep.sourceType === 'youtube' ? 'YouTube' : 'HTML5'}</small></span><button className="icon-button danger-icon" onClick={() => removeEpisode(ep.id)} aria-label={`Xóa tập ${ep.number}`}><Trash2 size={16} /></button></div>)}</div> : <p className="muted-note">Chưa có tập nào.</p>}</> : <EmptyState title="Chưa có anime để quản lý" text="Tìm anime ở khung bên trái hoặc tạo anime riêng." />}</section>
      <section className="admin-card"><div className="card-title-row"><div><div className="eyebrow">LIBRARY SETTINGS</div><h2>Danh sách anime</h2></div><Clapperboard size={20} /></div>{catalog.length ? <div className="managed-anime-list">{catalog.map((item) => <div key={item.id} className={String(item.id) === String(selectedId) ? 'selected' : ''}><button className="managed-anime-select" onClick={() => setSelectedId(item.id)}><Poster anime={item} /><span><strong>{item.title}</strong><small>{item.episodes?.length || 0} tập · {item.genres?.slice(0, 2).join(', ') || 'Chưa có thể loại'}</small></span></button><button className={`icon-button ${item.featured ? 'featured-icon' : ''}`} onClick={() => updateAnime(item.id, { featured: !item.featured })} title="Đánh dấu nổi bật"><Star size={16} fill={item.featured ? 'currentColor' : 'none'} /></button><button className="icon-button danger-icon" onClick={() => { if (window.confirm(`Xóa ${item.title} khỏi thư viện trên thiết bị?`)) { removeAnime(item.id); } }} aria-label="Xóa anime"><Trash2 size={16} /></button></div>)}</div> : <p className="muted-note">Chưa có anime.</p>}{selectedAnime && <><div className="admin-divider" /><h3>Lịch chiếu / nổi bật</h3><div className="form-two"><label>Thứ phát sóng<select value={scheduleDay} onChange={(e) => setScheduleDay(e.target.value)}><option value="">Không đặt lịch</option>{['Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy', 'Chủ Nhật'].map((day) => <option key={day}>{day}</option>)}</select></label><label>Giờ phát sóng<input type="time" value={scheduleTime} onChange={(e) => setScheduleTime(e.target.value)} /></label></div><div className="inline-actions"><button className="button button-outline button-small" onClick={saveSchedule}>Lưu lịch chiếu</button><button className="button button-outline button-small" onClick={toggleFeatured}><Star size={14} /> {selectedAnime.featured ? 'Bỏ nổi bật' : 'Đánh dấu nổi bật'}</button></div></>}</section>
      <section className="admin-card moderation-card"><div className="card-title-row"><div><div className="eyebrow">COMMUNITY MODERATION</div><h2>Bình luận được báo cáo ({reportedComments.length})</h2></div><ShieldAlert size={20} /></div>{reportedComments.length ? reportedComments.map((item) => <div className="moderation-item" key={item.id}><div><strong>{item.animeTitle} · {item.author}</strong><p>{item.body}</p></div><button className="icon-button danger-icon" onClick={() => removeComment(item.animeId, item.id)} aria-label="Xóa bình luận bị báo cáo"><Trash2 size={16} /></button></div>) : <p className="muted-note">Chưa có bình luận nào bị báo cáo trên thiết bị này.</p>}</section>
    </div>
  </div>;
}

function NotFoundPage() { return <div className="page-container page-top"><EmptyState title="Trang không tồn tại" text="Đường dẫn bạn truy cập không hợp lệ." action="/" actionLabel="Về trang chủ" /></div>; }
function statusLabel(status) { return ({ RELEASING: 'Đang phát sóng', FINISHED: 'Hoàn thành', NOT_YET_RELEASED: 'Sắp phát sóng', CANCELLED: 'Đã hủy', HIATUS: 'Tạm ngưng' })[status] || 'Chưa rõ trạng thái'; }

export default App;
