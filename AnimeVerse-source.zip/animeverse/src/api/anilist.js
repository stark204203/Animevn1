const API_URL = 'https://graphql.anilist.co';

const MEDIA_FIELDS = `
  id
  idMal
  title { romaji english native }
  synonyms
  coverImage { large extraLarge color }
  bannerImage
  description(asHtml: false)
  genres
  season
  seasonYear
  startDate { year month day }
  endDate { year month day }
  averageScore
  popularity
  episodes
  duration
  status
  format
  siteUrl
  studios(isMain: true) { nodes { id name } }
  trailer { id site thumbnail }
  nextAiringEpisode { episode airingAt timeUntilAiring }
`;

export async function aniListRequest(query, variables = {}, signal) {
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ query, variables }),
    signal,
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.errors?.length) {
    const message = payload.errors?.[0]?.message || `AniList trả về lỗi HTTP ${response.status}`;
    throw new Error(message);
  }
  return payload.data;
}

export async function searchAnime({ search, page = 1, genre = '', year = '', season = '', status = '', format = '', sort = 'POPULARITY_DESC' }, signal) {
  const query = `
    query (
      $search: String, $page: Int, $perPage: Int, $genres: [String],
      $seasonYear: Int, $season: MediaSeason, $yearLike: String, $status: [MediaStatus],
      $format: [MediaFormat], $sort: [MediaSort]
    ) {
      Page(page: $page, perPage: $perPage) {
        pageInfo { currentPage hasNextPage total }
        media(
          type: ANIME, search: $search, genre_in: $genres, seasonYear: $seasonYear,
          startDate_like: $yearLike, season: $season, status_in: $status, format_in: $format, sort: $sort,
          isAdult: false
        ) { ${MEDIA_FIELDS} }
      }
    }
  `;
  const variables = {
    search: search?.trim() || undefined,
    page,
    perPage: 24,
    genres: genre ? [genre] : undefined,
    seasonYear: year && season ? Number(year) : undefined,
    yearLike: year && !season ? `${year}%` : undefined,
    season: season || undefined,
    status: status ? [status] : undefined,
    format: format ? [format] : undefined,
    sort: [sort || 'POPULARITY_DESC'],
  };
  const data = await aniListRequest(query, variables, signal);
  return data.Page;
}

export async function getAnimeById(id, signal) {
  const query = `query ($id: Int) { Media(id: $id, type: ANIME) { ${MEDIA_FIELDS}
    staff(perPage: 8, sort: [RELEVANCE]) { edges { role node { name { full } } } }
    characters(perPage: 8, sort: [FAVOURITES_DESC]) { nodes { id name { full } image { medium } } }
  } }`;
  const data = await aniListRequest(query, { id: Number(id) }, signal);
  return data.Media;
}

export function normalizeAnime(media) {
  if (!media) return null;
  return {
    id: String(media.id),
    anilistId: Number(media.id),
    title: media.title?.english || media.title?.romaji || media.title?.native || 'Chưa có tên',
    titleRomaji: media.title?.romaji || '',
    titleEnglish: media.title?.english || '',
    titleNative: media.title?.native || '',
    synonyms: media.synonyms || [],
    poster: media.coverImage?.extraLarge || media.coverImage?.large || '',
    banner: media.bannerImage || '',
    description: stripHtml(media.description || ''),
    genres: media.genres || [],
    season: media.season || '',
    seasonYear: media.seasonYear || media.startDate?.year || null,
    year: media.startDate?.year || media.seasonYear || null,
    averageScore: media.averageScore || null,
    popularity: media.popularity || 0,
    episodesTotal: media.episodes || null,
    duration: media.duration || null,
    status: media.status || 'UNKNOWN',
    format: media.format || 'TV',
    siteUrl: media.siteUrl || '',
    studio: media.studios?.nodes?.[0]?.name || '',
    trailer: media.trailer || null,
    director: media.staff?.edges?.find((edge) => String(edge.role || '').toLowerCase().includes('director'))?.node?.name?.full || '',
    characters: media.characters?.nodes?.map((character) => ({ id: character.id, name: character.name?.full || 'Unknown', image: character.image?.medium || '' })) || [],
    nextAiringEpisode: media.nextAiringEpisode || null,
    episodes: [],
    addedAt: new Date().toISOString(),
    scheduleDay: '',
    scheduleTime: '',
    featured: false,
  };
}

export function stripHtml(value = '') {
  if (typeof document === 'undefined') return value.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
  const node = document.createElement('div');
  node.innerHTML = value;
  return (node.textContent || node.innerText || '').replace(/\s+/g, ' ').trim();
}
