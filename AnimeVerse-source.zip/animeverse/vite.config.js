import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // Relative assets + HashRouter make this project work on GitHub Pages
  // whether it is published at the domain root or /repository-name/.
  base: './',
});
